
import pandas as pd
from pathlib import Path

MAPPING_TSV = "fantom5_promoters_mapped_to_nearest_gencode_tss.tsv.gz"
OUTPUT_TSV = "gene_level_regulatory_table.tsv"

df = pd.read_csv(MAPPING_TSV, sep='\t', compression='gzip').astype({
    'promoter_tss': 'int32',
    'distance_to_gene_tss': 'int32',
    'cage_score': 'float32'
})

dominant_idx = df.groupby('gene_id')['cage_score'].idxmax()
dominant_rows = df.loc[dominant_idx].set_index('gene_id')[
    ['promoter_id', 'distance_to_gene_tss']
]

agg_df = df.groupby('gene_id').agg(
    gene_name=('gene_name', 'first'),
    num_promoters=('promoter_id', 'count'),
    total_cage=('cage_score', 'sum'),
    mean_cage=('cage_score', 'mean')
)

agg_df['dominant_promoter'] = dominant_rows['promoter_id']
agg_df['dominant_distance'] = dominant_rows['distance_to_gene_tss']

agg_df = agg_df.reset_index()[[
    'gene_id', 'gene_name', 'num_promoters',
    'dominant_promoter', 'total_cage', 'mean_cage', 'dominant_distance'
]].sort_values('gene_id')

agg_df.to_csv(OUTPUT_TSV, sep='\t', index=False)

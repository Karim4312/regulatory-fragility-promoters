
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
from scipy.stats import gaussian_kde

INPUT_FILE = "gene_level_regulatory_table.tsv"
OUTDIR = Path("figures")
OUTDIR.mkdir(exist_ok=True)

WIDTH_IN = 3.3
HEIGHT_IN = 2.55
FONT_TITLE = 9
FONT_LABEL = 8
FONT_TICK = 7
FONT_LEGEND = 7

plt.rcParams.update({
    'font.family': 'DejaVu Sans',
    'font.sans-serif': ['DejaVu Sans', 'Arial', 'Helvetica', 'sans-serif'],
    'font.size': FONT_TICK,
    'axes.titlesize': FONT_TITLE,
    'axes.labelsize': FONT_LABEL,
    'xtick.labelsize': FONT_TICK,
    'ytick.labelsize': FONT_TICK,
    'legend.fontsize': FONT_LEGEND,
    'axes.linewidth': 0.6,
    'xtick.major.width': 0.6,
    'ytick.major.width': 0.6,
    'xtick.major.size': 2.8,
    'ytick.major.size': 2.8,
    'lines.linewidth': 0.9,
    'figure.dpi': 400,
    'savefig.dpi': 800,
    'pdf.fonttype': 42,
    'savefig.transparent': True
})

df = pd.read_csv(INPUT_FILE, sep='\t')
df = df[(df['num_promoters'] >= 1) & (df['total_cage'] > 0) & df['dominant_distance'].notna()]

# Panel A: Histogram
figA, axA = plt.subplots(figsize=(WIDTH_IN, HEIGHT_IN), tight_layout=True)
axA.hist(df['num_promoters'], bins=np.arange(0.5, df['num_promoters'].max() + 1.5, 1), color='#2c7bb6', edgecolor='none')
axA.set_yscale('log')
axA.set_xlabel('Number of promoters per gene')
axA.set_ylabel('Number of genes (log)')
axA.set_title('Promoter redundancy', pad=8)
axA.spines['top'].set_visible(False)
axA.spines['right'].set_visible(False)
plt.savefig(OUTDIR / "A_hist_num_promoters_log_y.pdf", bbox_inches='tight')
plt.close(figA)

# Panel B: Scatter
figB, axB = plt.subplots(figsize=(WIDTH_IN, HEIGHT_IN), tight_layout=True)
x = np.log10(df['num_promoters'])
y = np.log10(df['total_cage'])
xy = np.vstack([x, y])
kde = gaussian_kde(xy)(xy)
idx = np.argsort(kde)
x, y, kde = x[idx], y[idx], kde[idx]
sc = axB.scatter(x, y, s=5, c=kde, cmap='viridis_r', alpha=0.95, edgecolor='none', rasterized=True)
axB.set_xlabel('log₁₀ (number of promoters)')
axB.set_ylabel('log₁₀ (total CAGE)')
axB.set_title('Promoter count vs activity', pad=8)
axB.grid(True, axis='both', linestyle=':', linewidth=0.4, alpha=0.3)
axB.spines['top'].set_visible(False)
axB.spines['right'].set_visible(False)
cbar = plt.colorbar(sc, ax=axB, shrink=0.65, aspect=25, pad=0.04)
cbar.set_label('Density', rotation=270, labelpad=8, fontsize=FONT_LABEL-1)
plt.savefig(OUTDIR / "B_scatter_num_vs_total_loglog.pdf", bbox_inches='tight')
plt.close(figB)

# Panel C: ECDF
figC, axC = plt.subplots(figsize=(WIDTH_IN, HEIGHT_IN), tight_layout=True)
dist = df['dominant_distance'].clip(lower=1)
log_dist = np.log10(dist)
sns.ecdfplot(x=log_dist, color='#d7191c', linewidth=1.2, ax=axC)
axC.set_xlabel('log₁₀ (distance to TSS [bp])')
axC.set_ylabel('Cumulative fraction')
axC.set_title('Dominant promoter proximity', pad=8)
for xref, ls, lbl in [(0, '--', 'TSS'), (2, ':', '100 bp'), (3, ':', '1 kb'), (4, ':', '10 kb')]:
    axC.axvline(xref, color='grey', lw=0.7, ls=ls, alpha=0.5, label=lbl)
axC.legend(frameon=False, loc='lower right', fontsize=FONT_LEGEND-1, handlelength=1.2)
axC.spines['top'].set_visible(False)
axC.spines['right'].set_visible(False)
plt.savefig(OUTDIR / "C_ecdf_dominant_distance_log.pdf", bbox_inches='tight')
plt.close(figC)

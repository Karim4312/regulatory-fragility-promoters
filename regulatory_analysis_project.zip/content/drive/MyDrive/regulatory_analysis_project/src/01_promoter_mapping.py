
import pandas as pd
import numpy as np
from pathlib import Path

# Configuration
PROMOTER_BED = "hg38_fair+new_CAGE_peaks_phase1and2.bed"
GENCODE_TSS_BED = "gencode_genes_tss_hg38.bed"
OUTPUT_TSV = "fantom5_promoters_mapped_to_nearest_gencode_tss.tsv.gz"

# Load promoter BED
df_prom = pd.read_csv(
    PROMOTER_BED, sep='\t', header=None,
    usecols=[0,1,2,3,4,5,6],
    names=['chr','start','end','name','score','strand','cage_score']
).astype({'start':'int32', 'end':'int32', 'score':'float32', 'cage_score':'float32'})

# Compute strand-aware TSS
df_prom['tss'] = np.where(
    df_prom['strand'] == '+',
    df_prom['start'],
    df_prom['end'] - 1
)

# Load GENCODE TSS BED
df_tss = pd.read_csv(
    GENCODE_TSS_BED, sep='\t', header=None,
    usecols=[0,1,2,3,4,5],
    names=['chr','start','end','gene_id','gene_name','strand']
).astype({'start':'int32', 'end':'int32'})

df_tss['tss'] = df_tss['start']

# Map per chromosome
result_rows = []
for chrom, prom_group in df_prom.groupby('chr', sort=False):
    if chrom not in df_tss['chr'].values:
        continue
    tss_group = df_tss[df_tss['chr'] == chrom].copy()
    tss_pos = tss_group['tss'].values
    tss_pos_sorted_idx = np.argsort(tss_pos)
    tss_pos_sorted = tss_pos[tss_pos_sorted_idx]
    for _, row in prom_group.iterrows():
        pos = row['tss']
        idx = np.searchsorted(tss_pos_sorted, pos)
        candidates = []
        if idx > 0:
            left_idx = tss_pos_sorted_idx[idx-1]
            left_dist = abs(pos - tss_group.iloc[left_idx]['tss'])
            candidates.append((left_dist, left_idx))
        if idx < len(tss_pos_sorted):
            right_idx = tss_pos_sorted_idx[idx]
            right_dist = abs(pos - tss_group.iloc[right_idx]['tss'])
            candidates.append((right_dist, right_idx))
        if not candidates:
            continue
        best_dist, best_tss_idx = min(candidates)
        best_gene = tss_group.iloc[best_tss_idx]
        result_rows.append({
            'promoter_id': row['name'],
            'chr': row['chr'],
            'promoter_tss': pos,
            'gene_id': best_gene['gene_id'],
            'gene_name': best_gene['gene_name'],
            'distance_to_gene_tss': best_dist,
            'cage_score': row['cage_score']
        })

df_result = pd.DataFrame(result_rows).sort_values(['chr', 'promoter_tss'])
df_result.to_csv(OUTPUT_TSV, sep='\t', index=False, compression='gzip')


# Regulatory Analysis of FANTOM5 Promoters and GENCODE Genes

## Overview
This project maps FANTOM5 CAGE promoters (hg38) to nearest GENCODE gene TSS, aggregates gene-level metrics, and generates publication-quality figures for regulatory fragility analysis.

## Data Sources
- FANTOM5 CAGE promoters: Downloaded from https://fantom.gsc.riken.jp/5/datafiles/latest/extra/CAGE_peaks/hg38_fair+new_CAGE_peaks_phase1and2.bed.gz
- GENCODE gene TSS: Derived from GENCODE comprehensive gene annotation GTF (e.g., release 49) at https://www.gencodegenes.org/human/, extracting strand-aware gene-level TSS positions in BED format.

## Directory Structure
- `src/`: Standalone Python scripts for each analysis step.
- `data/`: Input data files (upload your BED files here for reproduction).
- `figures/`: Publication-ready PDF figures.
- `outputs/`: Intermediate TSV files (mapping and gene-level table).
- `analysis_notebook.ipynb`: Full Colab notebook with all steps.

## Reproduction Steps
1. Place input BED files in `data/`.
2. Run scripts in order:
   - python src/01_promoter_mapping.py
   - python src/02_gene_aggregation.py
   - python src/03_generate_figures.py
3. Requirements: Python 3.x with pandas, numpy, matplotlib, seaborn, scipy.

For journal submission, this layout complies with Nature/Science data availability requirements. Upload to GitHub or Zenodo for DOI.
